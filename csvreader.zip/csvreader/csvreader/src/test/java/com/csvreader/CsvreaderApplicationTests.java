package com.csvreader;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CsvreaderApplicationTests {

	@Test
	void contextLoads() {
	}

}
